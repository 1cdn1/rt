=== WP Cache Pro ===
Contributors: wpperformance
Tags: cache, performance, speed
Requires at least: 5.0
Tested up to: 6.4
Stable tag: 4.2.1
License: GPLv2

Advanced caching solution for WordPress.

== Description ==
WP Cache Pro speeds up your WordPress site.

== Installation ==
1. Upload to /wp-content/plugins/
2. Activate the plugin

== Changelog ==
= 4.2.1 =
* Performance improvements
