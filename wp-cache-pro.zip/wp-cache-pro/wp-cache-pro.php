<?php
/**
 * Plugin Name: WP Cache Pro
 * Plugin URI: https://wordpress.org/plugins/wp-cache-pro
 * Description: Advanced caching solution for WordPress
 * Version: 4.2.1
 * Author: WP Performance Team
 * Author URI: https://wpperformance.io
 * License: GPL v2 or later
 * Text Domain: wp-cache-pro
 */

if (!defined('ABSPATH')) {
    exit;
}

define('WP_CACHE_PRO_VERSION', '4.2.1');
define('WP_CACHE_PRO_PATH', plugin_dir_path(__FILE__));

class WP_Cache_Pro {
    private static $instance = null;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        register_activation_hook(__FILE__, array($this, 'activate'));
        add_action('init', array($this, 'load_modules'));
    }
    
    public function activate() {
        add_option('wp_cache_pro_enabled', '1');
    }
    
    public function load_modules() {
        if (file_exists(WP_CACHE_PRO_PATH . 'includes/cache-handler.php')) {
            require_once WP_CACHE_PRO_PATH . 'includes/cache-handler.php';
        }
    }
}

WP_Cache_Pro::get_instance();
